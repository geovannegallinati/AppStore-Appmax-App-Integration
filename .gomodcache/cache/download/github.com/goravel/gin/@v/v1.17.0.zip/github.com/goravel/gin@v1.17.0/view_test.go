package gin

import (
	"net/http"
	"net/http/httptest"
	"testing"

	contractshttp "github.com/goravel/framework/contracts/http"
	foundationjson "github.com/goravel/framework/foundation/json"
	mocksconfig "github.com/goravel/framework/mocks/config"
	mocksview "github.com/goravel/framework/mocks/view"
	"github.com/goravel/framework/session"
	"github.com/goravel/framework/support/file"
	"github.com/goravel/framework/support/path"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestView_Make(t *testing.T) {
	var (
		err        error
		route      *Route
		req        *http.Request
		mockConfig *mocksconfig.Config
		mockView   *mocksview.View
	)

	assert.Nil(t, file.PutContent(path.Resource("views", "empty.tmpl"), `{{ define "empty.tmpl" }}
1
{{ end }}
`))
	assert.Nil(t, file.PutContent(path.Resource("views", "data.tmpl"), `{{ define "data.tmpl" }}
{{ .Name }}
{{ .Age }}
{{ end }}
`))
	defer func() {
		assert.Nil(t, file.Remove(path.Resource()))
	}()

	beforeEach := func() {
		mockConfig = mocksconfig.NewConfig(t)
		mockConfig.EXPECT().GetBool("app.debug").Return(false).Once()
		mockConfig.EXPECT().GetInt("http.drivers.gin.body_limit", 4096).Return(4096).Once()
		ConfigFacade = mockConfig

		mockView = mocksview.NewView(t)
		ViewFacade = mockView
	}
	tests := []struct {
		name        string
		method      string
		url         string
		setup       func(method, url string) error
		expectCode  int
		expectBody  string
		expectPanic bool
	}{
		{
			name:   "data is empty, shared is empty",
			method: "GET",
			url:    "/make/empty",
			setup: func(method, url string) error {
				mockView.EXPECT().GetShared().Return(nil).Once()

				route.Get("/make/empty", func(ctx contractshttp.Context) contractshttp.Response {
					return ctx.Response().View().Make("empty.tmpl")
				})

				var err error
				req, err = http.NewRequest(method, url, nil)
				if err != nil {
					return err
				}

				return nil
			},
			expectCode: http.StatusOK,
			expectBody: "\n1\n",
		},
		{
			name:   "data is empty, shared is not empty",
			method: "GET",
			url:    "/make/data",
			setup: func(method, url string) error {
				mockView.EXPECT().GetShared().Return(map[string]any{
					"Name": "test",
					"Age":  18,
				}).Once()

				route.Get("/make/data", func(ctx contractshttp.Context) contractshttp.Response {
					return ctx.Response().View().Make("data.tmpl")
				})

				var err error
				req, err = http.NewRequest(method, url, nil)
				if err != nil {
					return err
				}

				return nil
			},
			expectCode: http.StatusOK,
			expectBody: "\ntest\n18\n",
		},
		{
			name:   "data is not empty, shared is not empty",
			method: "GET",
			url:    "/make/data",
			setup: func(method, url string) error {
				mockView.EXPECT().GetShared().Return(map[string]any{
					"Name": "test",
				}).Once()

				route.Get("/make/data", func(ctx contractshttp.Context) contractshttp.Response {
					return ctx.Response().View().Make("data.tmpl", map[string]any{
						"Age": 18,
					})
				})

				var err error
				req, err = http.NewRequest(method, url, nil)
				if err != nil {
					return err
				}

				return nil
			},
			expectCode: http.StatusOK,
			expectBody: "\ntest\n18\n",
		},
		{
			name:   "data is not empty, shared is not empty, and data contains shared key",
			method: "GET",
			url:    "/make/data",
			setup: func(method, url string) error {
				mockView.EXPECT().GetShared().Return(map[string]any{
					"Name": "test",
				}).Once()

				route.Get("/make/data", func(ctx contractshttp.Context) contractshttp.Response {
					return ctx.Response().View().Make("data.tmpl", map[string]any{
						"Name": "test1",
						"Age":  18,
					})
				})

				var err error
				req, err = http.NewRequest(method, url, nil)
				if err != nil {
					return err
				}

				return nil
			},
			expectCode: http.StatusOK,
			expectBody: "\ntest1\n18\n",
		},
		{
			name:   "data is struct, shared is not empty, and data contains shared key",
			method: "GET",
			url:    "/make/data",
			setup: func(method, url string) error {
				mockView.EXPECT().GetShared().Return(map[string]any{
					"Name": "test",
				}).Once()

				route.Get("/make/data", func(ctx contractshttp.Context) contractshttp.Response {
					return ctx.Response().View().Make("data.tmpl", struct {
						Name string
						Age  int
					}{
						Name: "test1",
						Age:  18,
					})
				})

				var err error
				req, err = http.NewRequest(method, url, nil)
				if err != nil {
					return err
				}

				return nil
			},
			expectCode: http.StatusOK,
			expectBody: "\ntest1\n18\n",
		},
		{
			name:   "data is []string",
			method: "GET",
			url:    "/make/data",
			setup: func(method, url string) error {
				mockView.EXPECT().GetShared().Return(nil).Once()

				route.Get("/make/data", func(ctx contractshttp.Context) contractshttp.Response {
					assert.Panics(t, func() {
						ctx.Response().View().Make("data.tmpl", []string{"test"})
					})
					return nil
				})

				var err error
				req, err = http.NewRequest(method, url, nil)
				if err != nil {
					return err
				}
				return nil
			},
			expectCode: http.StatusOK,
			expectBody: "",
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			beforeEach()

			mockConfig.EXPECT().Get("http.drivers.gin.template").Return(nil).Once()

			route = &Route{
				config: mockConfig,
				driver: "gin",
			}
			err = route.init(nil)
			require.Nil(t, err)

			err = test.setup(test.method, test.url)
			require.Nil(t, err)

			w := httptest.NewRecorder()
			route.ServeHTTP(w, req)

			if test.expectBody != "" {
				assert.Nil(t, err)
				assert.Equal(t, test.expectBody, w.Body.String())
			}

			assert.Equal(t, test.expectCode, w.Code)
		})
	}
}

func TestView_First(t *testing.T) {
	var (
		err        error
		route      *Route
		req        *http.Request
		mockConfig *mocksconfig.Config
		mockView   *mocksview.View
	)

	assert.Nil(t, file.PutContent(path.Resource("views", "empty.tmpl"), `{{ define "empty.tmpl" }}
1
{{ end }}
`))
	assert.Nil(t, file.PutContent(path.Resource("views", "data.tmpl"), `{{ define "data.tmpl" }}
{{ .Name }}
{{ .Age }}
{{ end }}
`))

	defer func() {
		assert.Nil(t, file.Remove(path.Resource()))
	}()

	beforeEach := func() {
		mockConfig = mocksconfig.NewConfig(t)
		mockConfig.EXPECT().GetBool("app.debug").Return(false).Once()
		mockConfig.EXPECT().GetInt("http.drivers.gin.body_limit", 4096).Return(4096).Once()
		ConfigFacade = mockConfig

		mockView = mocksview.NewView(t)
		ViewFacade = mockView
	}
	tests := []struct {
		name        string
		method      string
		url         string
		setup       func(method, url string) error
		expectCode  int
		expectBody  string
		expectPanic bool
	}{
		{
			name:   "found the first view",
			method: "GET",
			url:    "/first",
			setup: func(method, url string) error {
				mockView.EXPECT().Exists("empty.tmpl").Return(true).Once()
				mockView.EXPECT().GetShared().Return(nil).Once()

				route.Get("/first", func(ctx contractshttp.Context) contractshttp.Response {
					return ctx.Response().View().First([]string{"empty.tmpl", "data.tmpl"})
				})

				var err error
				req, err = http.NewRequest(method, url, nil)
				if err != nil {
					return err
				}

				return nil
			},
			expectCode: http.StatusOK,
			expectBody: "\n1\n",
		},
		{
			name:   "found the second view",
			method: "GET",
			url:    "/first",
			setup: func(method, url string) error {
				mockView.EXPECT().Exists("empty.tmpl").Return(false).Once()
				mockView.EXPECT().Exists("data.tmpl").Return(true).Once()
				mockView.EXPECT().GetShared().Return(nil).Once()

				route.Get("/first", func(ctx contractshttp.Context) contractshttp.Response {
					return ctx.Response().View().First([]string{"empty.tmpl", "data.tmpl"}, map[string]any{
						"Name": "test",
						"Age":  18,
					})
				})

				var err error
				req, err = http.NewRequest(method, url, nil)
				if err != nil {
					return err
				}

				return nil
			},
			expectCode: http.StatusOK,
			expectBody: "\ntest\n18\n",
		},
		{
			name:   "no view found",
			method: "GET",
			url:    "/first",
			setup: func(method, url string) error {
				mockView.EXPECT().Exists("empty.tmpl").Return(false).Once()
				mockView.EXPECT().Exists("data.tmpl").Return(false).Once()

				route.Get("/first", func(ctx contractshttp.Context) contractshttp.Response {
					assert.Panics(t, func() {
						ctx.Response().View().First([]string{"empty.tmpl", "data.tmpl"}, map[string]any{
							"Name": "test",
							"Age":  18,
						})
					})

					return nil
				})

				var err error
				req, err = http.NewRequest(method, url, nil)
				if err != nil {
					return err
				}

				return nil
			},
			expectCode: http.StatusOK,
			expectBody: "",
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			beforeEach()

			mockConfig.EXPECT().Get("http.drivers.gin.template").Return(nil).Once()

			route = &Route{
				config: mockConfig,
				driver: "gin",
			}
			err = route.init(nil)
			require.Nil(t, err)

			err = test.setup(test.method, test.url)
			assert.Nil(t, err)

			w := httptest.NewRecorder()
			route.ServeHTTP(w, req)
			if test.expectBody != "" {
				assert.Equal(t, test.expectBody, w.Body.String())
			}

			assert.Equal(t, test.expectCode, w.Code)
		})
	}
}

func TestView_CSRFToken(t *testing.T) {
	assert.Nil(t, file.PutContent(path.Resource("views", "csrf.tmpl"), `{{ define "csrf.tmpl" }}
csrf_token={{ .csrf_token }}
{{ end }}
`))

	defer func() {
		assert.Nil(t, file.Remove(path.Resource()))
	}()

	mockConfig := mocksconfig.NewConfig(t)
	mockConfig.EXPECT().GetBool("app.debug").Return(false).Once()
	mockConfig.EXPECT().GetInt("http.drivers.gin.body_limit", 4096).Return(4096).Once()
	ConfigFacade = mockConfig

	mockView := mocksview.NewView(t)
	ViewFacade = mockView
	mockView.EXPECT().GetShared().Return(map[string]any{}).Once()

	t.Run("CSRF token", func(t *testing.T) {
		mockConfig.EXPECT().Get("http.drivers.gin.template").Return(nil).Once()

		route := &Route{
			config: mockConfig,
			driver: "gin",
		}
		err := route.init(nil)
		require.Nil(t, err)

		route.Get("/csrf", func(ctx contractshttp.Context) contractshttp.Response {
			sessionData := session.NewSession(sessionKey, nil, foundationjson.New())
			ctx.Request().SetSession(sessionData)
			err = sessionData.Regenerate()
			assert.Nil(t, err)

			return ctx.Response().View().Make("csrf.tmpl")
		})

		req, err := http.NewRequest("GET", "/csrf", nil)
		assert.Nil(t, err)
		w := httptest.NewRecorder()
		route.ServeHTTP(w, req)
		assert.Regexp(t, `^\ncsrf_token=([A-Za-z0-9\-_]+)\n$`, w.Body.String())
	})
}

func TestStructToMap(t *testing.T) {
	data := struct {
		Name string
		age  int
	}{
		Name: "test",
		age:  18,
	}

	dataMap := structToMap(data)
	assert.Equal(t, "test", dataMap["Name"])
	assert.Equal(t, 1, len(dataMap))

	dataMap = structToMap(&data)
	assert.Equal(t, "test", dataMap["Name"])
	assert.Equal(t, 1, len(dataMap))
}

func TestFillShared(t *testing.T) {
	shared := map[string]any{
		"Name": "test",
	}
	data := map[string]any{
		"Age": 18,
	}
	fillShared(data, shared)
	assert.Equal(t, "test", data["Name"])
	assert.Equal(t, 18, data["Age"])

	data = map[string]any{
		"Name": "test1",
		"Age":  18,
	}
	fillShared(data, shared)
	assert.Equal(t, "test1", data["Name"])
	assert.Equal(t, 18, data["Age"])

	type Map map[string]any
	data = Map{
		"Age": 18,
	}
	fillShared(data, shared)
	assert.Equal(t, "test", data["Name"])
	assert.Equal(t, 18, data["Age"])

	data = Map{
		"Name": "test1",
		"Age":  18,
	}
	fillShared(data, shared)
	assert.Equal(t, "test1", data["Name"])
	assert.Equal(t, 18, data["Age"])
}
